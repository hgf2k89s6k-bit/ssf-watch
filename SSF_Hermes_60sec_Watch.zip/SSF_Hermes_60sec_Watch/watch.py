import requests
ITEMS=[
("PP1-0117","https://www.ssfshop.com/PLEATS-PLEASE-ISSEY-MIYAKE/GM0026090810117/good","003"),
("PP1-0118","https://www.ssfshop.com/PLEATS-PLEASE-ISSEY-MIYAKE/GM0026090810118/good","003"),
("PP2-0855","https://www.ssfshop.com/PLEATS-PLEASE-ISSEY-MIYAKE/GM0026072960855/good",None),
("PP2-0856","https://www.ssfshop.com/PLEATS-PLEASE-ISSEY-MIYAKE/GM0026072960856/good",None),
("PP2-0857","https://www.ssfshop.com/PLEATS-PLEASE-ISSEY-MIYAKE/GM0026072960857/good",None),
("Hermes","https://www.hermes.com/kr/ko/product/neo-garden-23-%EB%B0%B1-H086418CKAC/",None)]
for n,u,s in ITEMS:
    print(n,u,s)
